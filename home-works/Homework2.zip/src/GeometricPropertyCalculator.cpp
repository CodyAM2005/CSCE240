#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <stdexcept>
#include <math.h>
#include <cmath>

using namespace std;

float Rectangle(float s1, float s2, int command)
{
    float result = -1;
    if(command == 1) //AREA
    {
        result = s1 * s2;
    }
    else if(command == 2) //Perimeter
    {
        result = s1*2+s2*2;
    }
    return result;
}
float Circle(float r, int command)
{
    float result = -1;
    if(command == 1) //AREA
    {
        result = r*r*M_PI;
    }
    else if(command == 2) //Perimeter
    {
        result = 2*r*M_PI;
    }
    return result;
}
float Triangle(float s1, float s2, float s3, int command)
{
    float result = -1;
    if(command == 1) //AREA
    {
        //Area of triangle with three sides is sqrt(s*(s-a)*(s-b)*(s-c)) where s is (a+b+c)/2
        float s = (s1+s2+s3)/2;
        result = sqrt(s*(s-s1)*(s-s2)*(s-s3));
    }
    else if(command == 2) //Perimeter
    {
        result = s1+s2+s3;
    }
    return result;
}
int main()
{
    int command = 0;

	//Number to see if you find the area of perimeter
    while(true)
    {
        command = -1;
        cout << "Would you like to find the area of perimeter of these shapes?\n\nArea: Input 1\nPerimeter: Input 2\n" << endl;
        try
        {
            cin >> command;
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            if(command != 1 && command != 2)
            {
                throw std::invalid_argument("command is not 1 or 2");
            }
            break;
        }
        catch(const std::exception& e)
        {
            cout << "Please make sure to input a number value that's either 1 or 2\n" << endl;
        }
        catch(...)
        {
            cout << "Please make sure the number is either 1 or 2\n" << endl;
        }
    }
    string typeOfCommand = "";
    if(command == 1)
        typeOfCommand = "AREA";
    else
        typeOfCommand = "PERIMETER";

    cout << "\nSounds good, so I'll be calculating the "+typeOfCommand+" for these shapes.\n-------------------------------------------------" << endl;

    string in_file_name = "/root/projects/helloworld/data/input.txt";
    string out_file_name = "/root/projects/helloworld/data/output.txt";
    string line;
    string s;

    ifstream in_myfile(in_file_name);
    ofstream out_myfile(out_file_name);
    if(in_myfile.is_open())
    {
        try
        {
            while(getline(in_myfile,line))
            {
                float result = -1;
                // getline(in_myfile, line);
                std::istringstream iss(line);
                getline(iss,s,' ');
                if(s.compare("RECTANGLE") == 0)
                {
                    string s1;
                    getline(iss,s1,' ');

                    string s2;
                    getline(iss,s2,' ');

                    result = Rectangle(stof(s1),stof(s2),command);
                    cout << s << " " << typeOfCommand << ": " << result <<endl;
                }
                else if(s.compare("CIRCLE") == 0)
                {
                    string r;
                    getline(iss,r,' ');

                    result = Circle(stof(r),command);\
                    cout << s << " " << typeOfCommand << ": " << result <<endl;
                }
                else if(s.compare("TRIANGLE") == 0)
                {
                    string s1;
                    getline(iss,s1,' ');

                    string s2;
                    getline(iss,s2,' ');

                    string s3;
                    getline(iss,s3,' ');

                    result = Triangle(stof(s1), stof(s2), stof(s3), command);
                    cout << s << " " << typeOfCommand << ": " << result <<endl;
                }
                else
                {
                    cout << "Proper shape was not provided"<<endl;
                }
                if(out_myfile.is_open()) 
                {
                    out_myfile << s << " " << typeOfCommand << ": " << result <<endl;
                }
                else 
                {
                    cout << "Unable to open output file - " << out_file_name << endl;
                }
            }
            cout << "-------------------------------------------------\nOutput printed to \"output.txt\" in the data folder" << endl;
            in_myfile.close();
            out_myfile.close();
        }
        catch(const std::exception& e)
        {
            cout << s << " " << typeOfCommand << ": Not enough information for shape provided"<<endl;
        }
    }
    else
    {
        cout << "Unable to open input file - " << out_file_name << endl;
    }
}