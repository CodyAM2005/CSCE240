#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <stdexcept>
#include <math.h>
#include <cmath>

using namespace std;

float Rectangle(float s1, float s2, int command)
{
    float result = s1*s2; //AREA
    if(command == 2 && result > 0) //Perimeter / Has to have positive area (valid shape)
    {
        result = s1*2+s2*2;
    }
    return result;
}
float Circle(float r, int command)
{
    float result = r*r*M_PI; //AREA
    if(command == 2 && result > 0) //Perimeter / Has to have positive area (valid shape)
    {
        result = 2*r*M_PI;
    }
    return result;
}
float Triangle(float s1, float s2, float s3, int command)
{
    //Area of triangle with three sides is sqrt(s*(s-a)*(s-b)*(s-c)) where s is (a+b+c)/2
    float s = (s1+s2+s3)/2;
    float result = sqrt(s*(s-s1)*(s-s2)*(s-s3)); //AREA
    if(command == 2 && result > 0) //Perimeter / Has to have positive area (valid shape)
    {
        result = s1+s2+s3;
    }
    return result;
}
int main()
{
    int command = 0;

	//Number to see if you find the area of perimeter
    while(true)
    {
        command = -1;
        cout << "Would you like to find the area of perimeter of these shapes?\n\nArea: Input 1\nPerimeter: Input 2\n" << endl;
        try
        {
            cin >> command;
            std::cin.clear(); 
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); //This and line above it handles errors from reading the cout lines
            if(command != 1 && command != 2)
            {
                throw std::invalid_argument("command is not 1 or 2"); //Throw exception because it wasn't a 1 or 2
            }
            break;
        }
        catch(...) //If didn't input a number, or if the number wasn't 1 or 2
        {
            cout << "Please make sure to input a number value that's either 1 or 2\n" << endl;
        }
    }
    string typeOfCommand = "";
    if(command == 1) //Depending on command input, either compute area or perimeter of shapes
        typeOfCommand = "AREA";
    else
        typeOfCommand = "PERIMETER";

    cout << "\nSounds good, so I'll be calculating the "+typeOfCommand+" for these shapes.\n-------------------------------------------------" << endl;

    string in_file_name = "/root/projects/helloworld/data/input.txt"; //Full file path because they are in different folders
    string out_file_name = "/root/projects/helloworld/data/output.txt";
    string line; //Variable that will get each line of input
    string s; //Variable that will get each word from the line

    ifstream in_myfile(in_file_name);
    ofstream out_myfile(out_file_name);
    if(in_myfile.is_open()) //Checks if the in-file opened properly
    {
        try
        {
            while(getline(in_myfile,line)) //Sets 'line' to the next line of the file, this code will run until it's out of shapes
            {
                float result = -1; //Result will be the answer to the computation
                std::istringstream iss(line); //Creates an istringstream, to parse through the 'line' variable
                getline(iss,s,' '); //Sets 's' to the next word of 'line'
                if(s.compare("RECTANGLE") == 0) //If the first word was "RECTANGLE"
                {
                    string s1;
                    getline(iss,s1,' '); //Sets the variable 's1' to be the next word in 'line'
                                         //This code is error handled, as if there isn't enough parameters, it will throw an exception
                    string s2;
                    getline(iss,s2,' '); //Sets the variable 's2' to be the next word in 'line'

                    result = Rectangle(stof(s1),stof(s2),command); //stof(s1) parses the value of the string to a float variable
                    cout << s << " " << typeOfCommand << ": " << result <<endl; //Writes it to the terminal
                }
                else if(s.compare("CIRCLE") == 0) //Check line 105's if statement to see how this if statement works
                {
                    string r;
                    getline(iss,r,' ');

                    result = Circle(stof(r),command);
                    cout << s << " " << typeOfCommand << ": " << result <<endl;
                }
                else if(s.compare("TRIANGLE") == 0) //Check line 105's if statement to see how this if statement works
                {
                    string s1;
                    getline(iss,s1,' ');

                    string s2;
                    getline(iss,s2,' ');

                    string s3;
                    getline(iss,s3,' ');

                    result = Triangle(stof(s1), stof(s2), stof(s3), command);
                    cout << s << " " << typeOfCommand << ": " << result <<endl;
                }
                else
                {
                    cout << "Proper shape was not provided"<<endl;
                    out_myfile << "Proper shape was not provided"<<endl;
                }
                if(out_myfile.is_open()) 
                {
                    if(result <= 0)
                    {
                        out_myfile << s << " has a negative or zero area, and is therefore not a valid shape" << endl;
                    }
                    else
                    {
                        out_myfile << s << " " << typeOfCommand << ": " << result <<endl;
                    }
                }
                else 
                {
                    cout << "Unable to open output file - " << out_file_name << endl;
                    out_myfile << "Unable to open output file - " << out_file_name << endl;
                }
            }
            cout << "-------------------------------------------------\nOutput printed to \"output.txt\" in the data folder" << endl;
            in_myfile.close(); //Closing the files after use
            out_myfile.close();
        }
        catch(const std::exception& e) //This code runs if it tried to get the next word in the line, and it didn't have one
        {
            cout << s << " " << typeOfCommand << ": Not enough information for shape provided"<<endl;
            out_myfile << s << " " << typeOfCommand << ": Not enough information for shape provided"<<endl;
        }
    }
    else
    {
        cout << "Unable to open input file - " << out_file_name << endl;
        out_myfile << "Unable to open input file - " << out_file_name << endl;
    }
}