#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    string in_file_name = "data/input.txt";
    string out_file_name = "data/output.txt";
    string line;

    string funky = "";
    string num1 = "-1";
    string num2 = "-1";

    ifstream in_myfile(in_file_name);
    if(in_myfile.is_open())
    {
        getline(in_myfile, line);
        funky = line;

        getline(in_myfile, line);
        num1 = line;
        //num1 = stoi(line);

        getline(in_myfile, line);
        num2 = line;
        //num2 = stoi(line);

        in_myfile.close();
    }
    else
    {
        cout << "Unable to open output file - " << out_file_name << endl;
    }

    int sum;
    if(funky.compare("multiply")==0)
    {
        sum = stoi(num1) * stoi(num2);
    }
    if(funky.compare("divide")==0)
    {
        sum = stoi(num1) / stoi(num2);
    }
    if(funky.compare("add")==0)
    {
        sum = stoi(num1) + stoi(num2);
    }
    if(funky.compare("subtract")==0)
    {
        sum = stoi(num1) - stoi(num2);
    }
    ofstream out_myfile(out_file_name);
    if(out_myfile.is_open()) 
    {
        string line1 = "The result of operation "+funky+" on "+num1+" and "+num2+" is below";
        out_myfile << line1 << endl;
        string line2 = to_string(sum);
        out_myfile << line2 << endl;
        out_myfile.close();
    }
    else 
    {
        cout << "Unable to open output file - " << out_file_name << endl;
    }
}
// string readFile()
// {
//     string in_file_name = "data/stuff.txt";
//     string out_file_name = "data/out.txt";
//     string line;

//     ifstream in_myfile(in_file_name);
//     ofstream out_myfile(out_file_name);
//     if(in_myfile.is_open()) {
//         if(out_myfile.is_open()) {
//             while(getline(in_myfile, line)) {
//                 cout << "\t reading .. - " << line << endl;
//                 string out_line = "A prefix - " + line + "\n";
//                 cout << "\t\t writing .. - " << out_line;
//                 out_myfile << out_line;
//             }
//             out_myfile.close();
//         } else {
//             cout << "Unable to open output file - " << out_file_name << endl;
//         }
//         in_myfile.close();
//     } else {
//         cout << "Unable to open input file - " << in_file_name << endl;
//     }
// }